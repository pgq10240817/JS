// ==UserScript==
// @name         PG_SIGN_SUCCESS_2_LOGOUT
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/home.php?mod=spacecp*
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';


var yhplPGURL = "http://bbs.pinggu.org/member.php?mod=logging&action=logout";
var yhplPGHOMEURL = "http://bbs.pinggu.org/member.php?mod=logging&action=login";
function yhplFunReLoad(){
    var yhplIDUserName = "username";
    var yhplDivUser = document.getElementById(yhplIDUserName);
    var isLogout = yhplDivUser!=null;
    if(isLogout){
        console.log('logout');
        window.location.href = yhplPGURL;
    }else{
        console.log('home');
        window.location.href = yhplPGHOMEURL;
    }
}
console.log('reg success page load');
setTimeout(yhplFunReLoad,1000);