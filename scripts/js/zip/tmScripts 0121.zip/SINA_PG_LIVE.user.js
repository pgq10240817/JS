// ==UserScript==
// @name         SINA_PG_LIVE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/home.php?mod=misc&ac=emailcheck*
// @grant        none
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// ==/UserScript==
/* jshint -W097 */
'use strict';
function yhplFunTurn(){
    console.log('yhplFunTurn');
    var yhplDiv = document.getElementById('messagetext');
    var yhplStr = yhplDiv.firstElementChild.innerText;
    if(yhplStr.indexOf('成功')>0){
        var yhplRegUserName = new RegExp("([^(]+\\()([^@]+)(@)");
        var yhplUserName = yhplStr.match(yhplRegUserName)[2];
        yhplFunUserUpdate(yhplUserName);
    }
}

function yhplFunUserUpdate(name){
    console.log('req user');
    var yhplGETURL = 'http://182.254.233.156:9000/userpg.email.update';
    var content = "userName="+name+"&flag=1";
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        data: content,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 
}

function yhplFunOnUserLoaded(data){
    console.log(' yhplFunOnUserLoaded  -->'+data);
    window.location.href='http://m1.mail.sina.com.cn/classic/index.php#action=maillist&fid=new';

}
function yhplFunError(){
    console.log('req user error');

}



function yhplFunClearTimeout(){
    console.log('yhplFunClearTimeout');
    var end = setTimeout(function(){},1);
    var start = (end -100)>0?end-100:0;
    for(var i=start;i<=end;i++){
        clearTimeout(i);
    }
}

console.log('scipts load');
yhplFunClearTimeout();
console.log('scipts load');
setTimeout(yhplFunTurn,1000);
