// ==UserScript==
// @name         EMuch_SIGN_LOGIN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://emuch.net/bbs/logging.php?action=login&t=*
// ==/UserScript==
/* jshint -W097 */
'use strict';


//Pre

var yhplGETURL = 'http://182.254.233.156:9000/useremuch.avauser';

function yhplFunGetCode(yhplStrCodeRaw){


    var yhplRegCode = '(问题：)([\\d]+)([^\\d]+)([\\d]+)';
    var yhplMatcher = yhplStrCodeRaw.match(yhplRegCode);
    var yhplCodeLeft = yhplMatcher[2];
    var yhplCodeRigh = yhplMatcher[4];
    var yhplCodeOperate = yhplMatcher[3];
    console.log('yhplCodeOperate:'+yhplCodeOperate+"l,r"+yhplCodeLeft+","+yhplCodeRigh);
    var yhplCodeBottom = -100000;
    if(yhplCodeOperate.indexOf('乘')>=0){

        yhplCodeBottom = yhplCodeLeft * yhplCodeRigh;
        console.log('乘:'+yhplCodeBottom);
    }else if(yhplCodeOperate.indexOf('除')>=0){
        yhplCodeBottom = yhplCodeLeft / yhplCodeRigh;
        console.log('除:'+yhplCodeBottom);
    }else if(yhplCodeOperate.indexOf('加')>=0){
        yhplCodeBottom = yhplCodeLeft + yhplCodeRigh;
        console.log('加:'+yhplCodeBottom);
    }else if(yhplCodeOperate.indexOf('减')>=0){
        yhplCodeBottom = yhplCodeLeft - yhplCodeRigh;
        console.log('减:'+yhplCodeBottom);
    }
    return yhplCodeBottom;

}


function yhplFunLogin(user){

    console.log('login');
    console.log('name,pwd'+user.name+","+user.pwd);
    $(".sinput")[0].value = user.name;
    $(".sinput")[1].value = user.pwd;
    $('.btn_sign')[0].click();
}

function yhplFunUserLoad(){
    console.log('req user');
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 
}

function yhplFunCross(){
    console.log('yhplFunCross');
    var yhplDivCodeLenth =  $.find('input[name=post_sec_code]').length;
    if(yhplDivCodeLenth == 0){//登陆
        yhplFunUserLoad();

    }else{//输入验证码
        var yhplInputCode =  $.find('input[name=post_sec_code]')[0];
        var yhplCode = yhplFunGetCode($($('form[name=input]')[0]).find('div')[0].innerText);
        console.log('code is :'+yhplCode);
        if(yhplCode == -10000){
            return;
        }
        yhplInputCode.value = yhplCode;
        $('input[name=loginsubmit]')[0].click();


    }
}

function yhplFunOnUserLoaded(data){
    if(data == null){
        console.log('get user is null  -->'+data);
    }else{
        yhplFunLogin(data);
    }
}

function yhplFunError(){
    console.log('req user error');
}
function yhplAddJQ(callback) {
    var script = document.createElement("script");
    script.setAttribute("src", "http://libs.baidu.com/jquery/1.9.0/jquery.js");
    script.addEventListener('load', function() {
        var script = document.createElement("script");
        script.textContent = "(" + callback.toString() + ")();";
        // console.log(script+":"+script.innerHTML);
        document.body.appendChild(script);
    }, false);
    document.body.appendChild(script);
}
function yhplJQReady(){
    console.log('yhplJQReady');
}
yhplAddJQ(yhplJQReady);
console.log('scipts load');
setTimeout(yhplFunCross,1000);

