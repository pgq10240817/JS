// ==UserScript==
// @name        pg_reg_reply_success
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/forum.php?mod=viewthread&tid=1018186*
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// ==/UserScript==
/* jshint -W097 */
'use strict';
var yhplPGURL = "http://bbs.pinggu.org/member.php?mod=logging&action=logout";
var yhplPGHOMEURL = "http://bbs.pinggu.org/member.php?mod=regpinggu";
var yhplFlagLiveEmailCount = 0;

function yhplFunReLoad(){
    var yhplIDUserName = "username";
    var yhplDivUser = document.getElementById(yhplIDUserName);
    var isLogin = yhplDivUser!=null;
    if(isLogin){
        console.log('logout');
        window.location.href = yhplPGURL;
    }else{
        console.log('reg page');
        window.location.href = yhplPGHOMEURL;
    }
}
function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
    yhplFunReLoad();
}
function yhplFunError(){
    yhplFlagLiveEmailCount = yhplFlagLiveEmailCount + 1;
    console.log('yhplFunError:');
    yhplFunReLoad();

}

function yhplFunUploadUser(){
    console.log('upload user');
    var yhplIDUserName = "username";
    var yhplDivUser = document.getElementById(yhplIDUserName);
    if(yhplDivUser==null){
        yhplFunReLoad();
        return;
    }
    var yhplUserName = yhplDivUser.firstChild.innerText;
    var yhplUserPwd = "pg"+yhplUserName.substring(4);

    var yhplPOSTContentExtraObj = {};
    yhplPOSTContentExtraObj.v="2";
    var yhplPOSTContentExtra = "&extra="+encodeURIComponent(JSON.stringify(yhplPOSTContentExtraObj));
    var yhplPOSTContent = "name="+yhplUserName+"&pwd="+yhplUserPwd+yhplPOSTContentExtra;
    var yhplPOSTUrl = 'http://182.254.233.156:9000/userpg.insert';
    $.ajax({
        type: "POST",
        url: yhplPOSTUrl,
        data: yhplPOSTContent,
        success: yhplFunUpIUserCall,
        error:yhplFunUpIUserCallError,
        dataType: 'jsonp'
    }); 

}

function yhplFunUpIUserCall(data){
    console.log('yhplFunUpIUserCall:'+data);
    yhplFunReLoad();

}
function yhplFunUpIUserCallError(){
    console.log('yhplFunUpIUserCallError:');
    yhplFunReLoad();
}

console.log('reply success page load');
setTimeout(yhplFunUploadUser,200);
//setTimeout(yhplFunReLoad,3000);