// ==UserScript==
// @name         EMuch_SIGN_MAIN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://emuch.net/bbs/index.php
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';


function yhplFunCross(){
    console.log('yhplFunCross');
    var yhplInputUser= $("a[href^='logging.php']")[0];
    var yhplStrLogin =  yhplInputUser.innerText;
    if(yhplStrLogin.indexOf('登录')>0){//登录
        console.log('登录');
        yhplInputUser.click();
    }else{//退出
        console.log('退出');
        window.location.href= 'http://emuch.net/bbs/memcp.php?action=getcredit';
    }

    //

}



function yhplFunError(){
    console.log('req user error');
}
function yhplAddJQ(callback) {
    var script = document.createElement("script");
    script.setAttribute("src", "http://libs.baidu.com/jquery/1.9.0/jquery.js");
    script.addEventListener('load', function() {
        var script = document.createElement("script");
        script.textContent = "(" + callback.toString() + ")();";
        // console.log(script+":"+script.innerHTML);
        document.body.appendChild(script);
    }, false);
    document.body.appendChild(script);
}
function yhplJQReady(){
    console.log('yhplJQReady');
}
yhplAddJQ(yhplJQReady);
console.log('scipts load');
setTimeout(yhplFunCross,1000);

