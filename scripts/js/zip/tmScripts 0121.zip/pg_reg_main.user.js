// ==UserScript==
// @name         pg_reg_main
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/member.php?mod=regpinggu*
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
/* jshint -W097 */
'use strict';
//common
//Pre. 
//var yhplPGURLBase = "http://bbs.pinggu.org/member.php?mod=regpinggu&fromuid=";
//var yhplPGURLUID = "7862414";
var yhplPGURLBase = "http://bbs.pinggu.org/member.php?mod=regpinggu";
var yhplPGURLUID = "";
var yhplPGURL = yhplPGURLBase+yhplPGURLUID;
var yhplTimeoutReg = 2 * 1000;


var yhplDate = new Date();
var yhplUserRandom = yhplDate.getDate()+''+yhplDate.getHours()+''+yhplDate.getMinutes()+''+yhplDate.getSeconds();
var yhplUserName = "tp0d"+yhplUserRandom;
var yhplUserPwd = "pg"+yhplUserRandom;
var yhplUserMail = yhplUserName  + "@duckweed.pw";
function yhplFunLogin(){
    // Pre. 1. CODE ID
    var yhplIDInputcodeRaw = document.getElementsByName("secanswer")[0].id;
    var yhplIDInputcodeRawReg = new RegExp("(_)([^_]+$)");   
    var yhplIDInputcodeAfterFix = yhplIDInputcodeRaw.match(yhplIDInputcodeRawReg)[2];

    // DEL 1.ID
    var yhplIDInputName = "pgname221a";
    var yhplIDInputPwd = "pgpass1121a";
    var yhplIDInputPwd2 = "pgpass1221a";
    var yhplIDInputEmail = "pgemail4521a";
    var yhplCLZCb = 'pc';
    var yhplIDInputCode = "secqaaverify_"+yhplIDInputcodeAfterFix;
    var yhplIDSpanCode = "secqaa_"+yhplIDInputcodeAfterFix;
    var yhplIDSubmit = 'registerformsubmit';

    // A. NORMAL 
    document.getElementById(yhplIDInputName).value = yhplUserName ;
    document.getElementById(yhplIDInputPwd).value = yhplUserPwd;
    document.getElementById(yhplIDInputPwd2).value = yhplUserPwd;
    document.getElementById(yhplIDInputEmail).value = yhplUserMail;
    document.getElementsByClassName(yhplCLZCb)[0].checked =true

    // B. CODE

    var yhplCodeStr = document.getElementById(yhplIDSpanCode).innerHTML;
    if(yhplCodeStr==null || yhplCodeStr.length==0){
        console.log('user upload erroer code is null');
        yhplFunReLoad();
        return;
    }
    var yhplCodeReg = new RegExp("([^>]+)(<[^<]+$)");   
    var yhplCodeRight = yhplCodeStr.match(yhplCodeReg)[1];
    document.getElementById(yhplIDInputCode).value = yhplCodeRight;


    // C. SUBMIT
    document.getElementById(yhplIDSubmit).click();
    console.log('user reged');

}
function yhplFunReLoad(){
    //window.location.href = yhplPGURL;
    window.location.reload();
    // document.getElementsByClassName('xi2')[1].click()
    // setTimeout(yhplFunLogin,2000);
}

function yhplMain(){
    console.log('main enter');
    yhplFunLogin();
}
console.log('load---');
console.log('test vat--'+yhplUserName);
setTimeout(yhplMain,yhplTimeoutReg);