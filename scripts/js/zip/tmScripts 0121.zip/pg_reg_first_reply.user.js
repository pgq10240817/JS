// ==UserScript==
// @name         pg_reg_first_reply
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/thread-1018186-1-1.html
// @match        http://bbs.pinggu.org/forum.php?mod=post&action=reply&fid=145&tid=1018186&extra=&replysubmit=yes&infloat=yes&handlekey=fastpost
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';
var yhplFlagCheckStep = 0;

function yhplFunReply(){
    console.log('yhplFunReply');
    // Pre. 1. CODE ID
    var yhplIDInputcodeRaw = document.getElementsByName("secanswer")[0].id;
    var yhplIDInputcodeRawReg = new RegExp("(_)([^_]+$)");   
    var yhplIDInputcodeAfterFix = yhplIDInputcodeRaw.match(yhplIDInputcodeRawReg)[2];
    var yhplIDInputCode = "secqaaverify_"+yhplIDInputcodeAfterFix;
    var yhplIDSpanCode = "secqaa_"+yhplIDInputcodeAfterFix;

    var yhplCodeStr = document.getElementById(yhplIDSpanCode).innerHTML;
    if(yhplCodeStr==null || yhplCodeStr.length==0){
        console.log('code is null');
        setTimeout(yhplFunReload,1000);
        return;
    }
    var yhplCodeReg = new RegExp("([^>]+)(<[^<]+$)");   
    var yhplCodeRight = yhplCodeStr.match(yhplCodeReg)[1];
    console.log('yhplCodeStr:'+yhplCodeStr);
    document.getElementById(yhplIDInputCode).value = yhplCodeRight;
    checksec('qaa', yhplIDInputcodeAfterFix);
    document.getElementById('fastpostmessage').value = '谢谢分享!!!';
    setTimeout(yhplRelySubmit,1000);

}
function yhplRelySubmit(){
    console.log('yhplRelySubmit');
    document.getElementById('fastpostsubmit').click();
}
function yhplFunShowConfirm(){
    console.log('yhplFunShowConfirm');
    showWindow('tiaokuan', 'http://bbs.pinggu.org/z_tiaokuan.php?myurl=http%3A%2F%2Fbbs.pinggu.org%2Fthread-1018186-1-1.html')
    setTimeout(yhplFunConfirm,500);
}
function yhplFunReload(){
    console.log('yhplFunReload')
    window.location.href = "http://bbs.pinggu.org/thread-1018186-1-1.html";
}
function yhplFunConfirm(){
    var yhplUrlNow  = window.location.href;

    if(yhplUrlNow.indexOf('replysubmit=yes') > 0){//error occ
        setTimeout(yhplFunReload,1000);
        return;
    }

    yhplFlagCheckStep = yhplFlagCheckStep + 1;
    console.log('yhplFunConfirm');
    var yhplInputCodeCheck = document.getElementsByName('confirm')[0];
    console.log('yhplFunConfirm step:'+yhplFlagCheckStep);
    if(yhplInputCodeCheck!=null){
        document.getElementsByName('confirm')[0].click();
    }else{
        if(yhplFlagCheckStep<10){
            setTimeout(yhplFunConfirm,500);
        }else{
            console.log('reload');
            window.location.reload();
        }

    }


}
function yhplFunCheckSwitch(){
    var yhplInput = document.getElementById('fastpostmessage');
    if(yhplInput!=null){
        yhplFunReply();
    }else{
        yhplFunShowConfirm();
    }

}
setTimeout(yhplFunCheckSwitch,1000);
console.log('reply page load');