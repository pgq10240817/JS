// ==UserScript==
// @name         EMuch_SIGN_SIGN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://emuch.net/bbs/memcp.php?action=getcredit
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';

var yhplGETURL = 'http://182.254.233.156:9000/useremuch.update';

function yhplFunCross(){
    console.log('yhplFunCross');
    var yhplInputSign = $('input[name=creditsubmit]')[0];
    if(yhplInputSign!=null){//sign
        console.log('yhplFunCross begin sign');
        $('input[name=creditsubmit]')[0].click();
    }else{
        yhplFunUploadUser();
    }
}


function yhplFunGetTrimSignStr(){
    var yhplDivSpanSignDay = $('td div b')[0];
    var yhplDivSpanRoot = yhplDivSpanSignDay.parentNode.parentNode;
    var yhplStrSignRaw = yhplDivSpanRoot.innerText;
    var yhplStrSignGroup = yhplStrSignRaw.split('\n');
    var yhplStrSignResult = '';
    for(var step = 0;step<yhplStrSignGroup.length;step++){
        var tmpStr = yhplStrSignGroup[step];
        if(tmpStr.indexOf('已经连续') >=0 ||tmpStr.indexOf('金币数') >=0 ){
            yhplStrSignResult = yhplStrSignResult + tmpStr;
        }
    }
    return yhplStrSignResult;
}
// --上传签到信息
function yhplFunUploadUser(){
    var username = $("a[href^='space.php?uid=']")[2].innerText;
    var content = yhplFunGetTrimSignStr();
    console.log(' sign success upload');
    console.log(username+'  sign result:'+content);
    var yhplPOSTContentExtra = "&extra="+encodeURI(content);
    var yhplPOSTContent = "userName="+username+yhplPOSTContentExtra;
       $.ajax({
        type: "GET",
        url: yhplGETURL,
        contentType:"application/x-www-form-urlencoded; charset=UTF-8",
        data: yhplPOSTContent,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 
}

function yhplFunOnUserLoaded(data){
    console.log('yhplFunOnUserLoaded logout');
    $("a[href^='logging.php']")[0].click();
}
function yhplFunError(){
    console.log('upload error');
}


function yhplAddJQ(callback) {
    var script = document.createElement("script");
    script.setAttribute("src", "http://libs.baidu.com/jquery/1.9.0/jquery.js");
    script.addEventListener('load', function() {
        var script = document.createElement("script");
        script.textContent = "(" + callback.toString() + ")();";
        // console.log(script+":"+script.innerHTML);
        document.body.appendChild(script);
    }, false);
    document.body.appendChild(script);
}
function yhplJQReady(){
    console.log('yhplJQReady');
}
yhplAddJQ(yhplJQReady);
console.log('scipts load');
setTimeout(yhplFunCross,1000);