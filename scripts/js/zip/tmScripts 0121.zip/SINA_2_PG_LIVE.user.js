// ==UserScript==
// @name         SINA_2_PG_LIVE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://m1.mail.sina.com.cn/*
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';
function yhplFunCheck(){
    var yhplDivText= document.getElementsByClassName('mailMainArea')[0];
    if(yhplDivText==null){
        yhplFunEnterDetail();
        return;
    }
    yhplFunTurn();
}
function yhplFunTurn(){
    console.log('yhplFunTurn');
    var yhplDivText= document.getElementsByClassName('mailMainArea')[0];
    var yhplStr= yhplDivText.getElementsByTagName('p')[0].innerHTML;
    var yhplRegUserName = new RegExp("([^，]+)(.+)");
    var yhplUserName = yhplStr.match(yhplRegUserName)[1];

    var yhplLiveMail = yhplDivText.getElementsByTagName('a')[0].href
   // yhplFunMoveDel();
    window.location.href = yhplLiveMail;
}
function yhplFunMoveDel(){
    console.log('yhplFunMoveDel');
    var yhplDivs = document.getElementsByTagName('a');
    var length = yhplDivs.length;
    for(var i =0; i<length;i++){
        if(yhplDivs[i].title == "已删除"){
            console.log('move email to del')
            yhplDivs[i].click();
            break;

        }
    }
}
function yhplFunEnterDetail(){
    console.log('yhplFunEnterDetail ');
    var yhplDivs = document.getElementsByClassName('listrow lev_low noRead');
    var length = yhplDivs.length;
    for(var i =0;i<length;i++){
        var yhplDivTitle = yhplDivs[i].getElementsByClassName('subject spec')[0];
        if(yhplDivTitle.title == "[人大经济论坛] Email 地址验证"){
            yhplDivTitle.click();
            setTimeout(yhplFunTurn,1000);
            break;
        }
    }
}
console.log('scipts load');
setTimeout(yhplFunCheck,1000);
