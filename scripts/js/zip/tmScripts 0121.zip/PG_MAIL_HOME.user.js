// ==UserScript==
// @name         PG_MAIL_HOME
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/
// @match        http://bbs.pinggu.org/member.php?mod=logging&action=logout
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
/* jshint -W097 */

var yhplURLLogin = "http://bbs.pinggu.org/member.php?mod=logging&action=login";
function yhplFunToLoginPage(){
    console.log('turn to login');
    window.location.href = yhplURLLogin;
}
function yhplFunClearTimeout(){
    console.log('yhplFunClearTimeout');
    var end = setTimeout(function(){},1);
    var start = (end -100)>0?end-100:0;
    for(var i=start;i<=end;i++){
        clearTimeout(i);
    }
}
console.log('scipts home load');
yhplFunClearTimeout();
setTimeout(yhplFunToLoginPage,100);

