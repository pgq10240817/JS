// ==UserScript==
// @name         PG_MAIL_LIVE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password*
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
/* jshint -W097 */


//Pre

var yhplCountDownReSendMail = 60;

var yhplURLLogout ='http://bbs.pinggu.org/member.php?mod=logging&action=logout';
function yhplFunIMailError(){
    console.log('yhplFunError');
}
function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
}
function yhplLiveMail(){
    console.log('send endter');
    $.ajax({
        type: "GET",
        url: 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1',
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success: yhplFunUpILiveMail,
        error:yhplFunIMailError,
    });  
}

function yhplFunLive(){
    console.log(' yhplFunLive');
    var div = document.getElementById('messagetext');
    var yhplStr = div.getElementsByTagName('p')[0].innerHTML;
    if(yhplStr.startsWith('邮件已发送，可能需要几分钟后才能收到邮件')){
        //  var yhplStr = div.getElementsByTagName('p')[0].innerHTML = 'test';
        console.log('send mail success');
        yhplCountDownReSendMail = -100;
        yhplFunUploadUser(100);
    }else{
        console.log('send mail failed');
        yhplFunUploadUser(-1);
        yhplFunCountDown();
    }

}
function delHtmlTag(str){
    return str.replace(/<[^>]+>/g,"");//去掉所有的html标记
}


function yhplFunUploadUser(flag){
    var yhplPOSTUserName = delHtmlTag(document.getElementById('username').innerHTML);
    var yhplPOSTContent = "userName="+yhplPOSTUserName+"&flag="+flag;
    var yhplGETURL = 'http://182.254.233.156:9000/userpg.email.update';
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        data: yhplPOSTContent,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 
}
function success_jsonpCallback(data){
    console.log('data result  -->'+data);
}
function yhplFunOnUserLoaded(data){
    if(data == null){
        console.log('get user is null  -->'+data);
    }else{
        console.log('get result  -->'+data.result);
    }
    window.location.href = yhplURLLogout;

}
function yhplFunError(){
    console.log('req user error');
    if(yhplCountDownReSendMail==-100){
        window.location.href = yhplURLLogout;
    }
}
function yhplFunClearTimeout(){
    console.log('yhplFunClearTimeout');
    var end = setTimeout(function(){},1);
    var start = (end -100)>0?end-100:0;
    for(var i=start;i<=end;i++){
        clearTimeout(i);
    }
}
function yhplFunCountDown(){
    console.log('yhplFunCountDown :'+yhplCountDownReSendMail);
    if(yhplCountDownReSendMail>=0){
        yhplCountDownReSendMail = yhplCountDownReSendMail-1;
        if(yhplCountDownReSendMail==0){
            yhplCountDownReSendMail = -100;
           // setTimeout(yhplFunLive,2000);
            window.location.reload();
        }else{
            setTimeout(yhplFunCountDown,1000);
        }
    }
}

console.log('scipts load');
yhplFunClearTimeout();
setTimeout(yhplFunLive,2000);