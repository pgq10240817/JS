// ==UserScript==
// @name         PG_LIVE_SEND_MAIL
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/thread-1018186-1-1.html
// @grant        none
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// ==/UserScript==
/* jshint -W097 */
'use strict';

function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
}
function yhplFunError(){
    console.log('yhplFunError');
}
function yhplLiveMail(){
    console.log('send endter');
    $.ajax({
        type: "get",
        url: 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1',
        success: yhplFunUpILiveMail,
        error:yhplFunError,
        dataType: 'json'
    }); 
}
console.log('send mail');
setTimeout(yhplLiveMail,200);