// ==UserScript==
// @name        MAIL_PG
// @namespace   test
// @description bbs.pinggu.org
// @version     1
// @grant       none
// @match       http://bbs.pinggu.org/member.php?mod=logging&action=login&name=*
// @run-at document-end
// ==/UserScript==
'use strict';
function yhpllogin(name) {
  var pwd = 'pg'+name.substring(8);
  var yhplIDInputNameRaw = document.getElementsByName('username') [0].id;
  var yhplIDInputNameRawReg = new RegExp('(_)([^_]+$)');
  var yhplIDInputNameAfterFix = yhplIDInputNameRaw.match(yhplIDInputNameRawReg) [2];
  var yhplIDUserName = 'username_';
  var yhplIDUserPwd = 'password3_';
  yhplIDUserName = yhplIDUserName + yhplIDInputNameAfterFix;
  yhplIDUserPwd = yhplIDUserPwd + yhplIDInputNameAfterFix;
  document.getElementById(yhplIDUserName).value = name;
  document.getElementById(yhplIDUserPwd).value = pwd;
  document.getElementsByName('loginsubmit') [0].click();
}
function getUrlPar(name){
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}
function main() {
  console.log('main');
 
  var name = getUrlPar('name');
  console.log('name.'+name);
  if (name != null && name.length > 0) {
    yhpllogin(name);
  }
}
console.log('load 222');
setTimeout(main, 100);
