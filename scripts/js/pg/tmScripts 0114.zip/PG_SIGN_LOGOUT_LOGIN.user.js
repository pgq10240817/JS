// ==UserScript==
// @name         PG_SIGN_LOGOUT_LOGIN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/member.php?mod=logging&action=logout
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';

var yhplURLLogin = "http://bbs.pinggu.org/member.php?mod=logging&action=login";
function yhplFunReLoad(){
        console.log('login');
        window.location.href = yhplURLLogin;
}
console.log('reg success page load');
setTimeout(yhplFunReLoad,200);