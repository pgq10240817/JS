// ==UserScript==
// @name         PG_LIVE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';

var yhplPGURL = "http://bbs.pinggu.org/forum.php?mod=post&action=reply&fid=145&tid=1075758";
function yhplFunReLoad(){
   window.location.href = yhplPGURL;
}
console.log('live success page load');
setTimeout(yhplFunReLoad,100);