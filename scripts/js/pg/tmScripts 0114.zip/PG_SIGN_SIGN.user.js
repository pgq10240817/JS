// ==UserScript==
// @name         PG_SIGN_SIGN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/plugin.php?id=dsu_paulsign:sign*
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
/* jshint -W097 */


//Pre

var yhplURLLOGOUT = 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=main';
var yhplURLLogout ='http://bbs.pinggu.org/member.php?mod=logging&action=logout';
var yhplFlagCheck = 0;

function yhplFunIMailError(){
    console.log('yhplFunError');
}
function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
}
function yhplLiveMail(){
    console.log('send endter');
    $.ajax({
        type: "get",
        url: 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1',
        success: yhplFunUpILiveMail,
        error:yhplFunIMailError,
        dataType: 'json'
    }); 
}

function yhplFunSign(){
    console.log(' yhplFunSign');
    console.log('111111');
    // yhplLiveMail();
    var isSingeg = document.getElementById('kx')==null;
    if(isSingeg){
        console.log('singed - so,upload data ');
        yhplFunUploadUser();
    }else{
        Icon_selected('kx');
        var yhplRadiosArray = document.getElementsByName('qdmode');
        yhplRadiosArray[1].click();
        showWindow('qwindow', 'qiandao', 'post', '0');
        yhplFlagCheck = yhplFlagCheck+1;
        setTimeout(yhplFunSignReload,1000);
    }
}
// ---- 可能邮箱未激活
function yhplFunMailInvalided(name){
    console.log('yhplFunMailInvalided user');
    var yhplGETURL = 'http://182.254.233.156:9000/userpg.email.update';
    var content = "userName="+name+"&flag=-1";
   //var yhplPOSTContent = "username="+name;
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        data: content,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunMailInvalidedOnSuccess,
        error :yhplFunMailInvalidedOnError
    }); 
}

function yhplFunMailInvalidedOnSuccess(data){
    console.log(' yhplFunMailInvalidedOnSuccess  -->'+data);
     window.location.href = yhplURLLogout;

}
function yhplFunMailInvalidedOnError(){
    console.log('yhplFunMailInvalidedOnError  error');
     window.location.href = yhplURLLogout;

}


function yhplFunSignReload(){
    console.log('yhplFunSignReload '+yhplFlagCheck);
    if(yhplFlagCheck < 3){
        //  console.log('reload ');
        //  window.location.reload();
        console.log('resign ');
        setTimeout(yhplFunSign,1000);
    }else{
        var yhplPOSTUserName = delHtmlTag(document.getElementById('username').innerHTML);
        yhplFunMailInvalided(yhplPOSTUserName);
    }
}
function delHtmlTag(str){
    return str.replace(/<[^>]+>/g,"");//去掉所有的html标记
}

// --上传签到信息
function yhplFunUploadUser(){
    var yhplDetailRaw = document.getElementsByClassName('qdnewinfo')[0].innerHTML;
    var yhplPOSTContentExtraObj = {};
    var yhplPOSTUserName = delHtmlTag(document.getElementById('username').innerHTML);
    yhplPOSTContentExtraObj.detail=delHtmlTag(yhplDetailRaw);
    var yhplPOSTContentExtra = "&extra="+encodeURIComponent(JSON.stringify(yhplPOSTContentExtraObj));
    var yhplPOSTContent = "userName="+yhplPOSTUserName+yhplPOSTContentExtra;
    var yhplGETURL = 'http://182.254.233.156:9000/userpg.update';
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        data: yhplPOSTContent,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 

    /*    $.ajax({
        type: "GET",
        url: yhplGETURL,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); */

}
function success_jsonpCallback(data){
    console.log('data result  -->'+data);
}
function yhplFunOnUserLoaded(data){
    if(data == null){
        console.log('get user is null  -->'+data);
    }else{
        console.log('get result  -->'+data.result);
    }
    window.location.href = yhplURLLogout;

}
function yhplFunError(){
    console.log('req user error');
    window.location.href = yhplURLLogout;
}
function yhplFunClearTimeout(){
    console.log('yhplFunClearTimeout');
    var end = setTimeout(function(){},1);
    var start = (end -100)>0?end-100:0;
    for(var i=start;i<=end;i++){
        clearTimeout(i);
    }
}
console.log('scipts load');
setTimeout(yhplFunSign,400);
//setTimeout(yhplFunSign,1400);

