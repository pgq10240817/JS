// ==UserScript==
// @name         PG_SIGN_TO_SIGN_PAGE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/member.php?mod=logging&action=login&loginsubmit=yes&*
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';
var yhplURLSign = "http://bbs.pinggu.org/plugin.php?id=dsu_paulsign:sign#qdform";
function yhplFunToSignPage(){
    console.log('turn to sign');
    window.location.href = yhplURLSign;
}
console.log('scipts load');
setTimeout(yhplFunToSignPage,100);

