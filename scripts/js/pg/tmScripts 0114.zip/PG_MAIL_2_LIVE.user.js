// ==UserScript==
// @name         PG_MAIL_2_LIVE
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/member.php?mod=logging&action=login&loginsubmit=yes&*
// @match        http://bbs.pinggu.org/thread-1018186-1-1.html
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
/* jshint -W097 */


//Pre


var yhplURL ='http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1';

function yhplFunTurn(){
    console.log('yhplFunTurn:'+yhplURL);
    window.location.href = yhplURL;
}
function yhplFunClearTimeout(){
    console.log('yhplFunClearTimeout');
    var end = setTimeout(function(){},1);
    var start = (end -100)>0?end-100:0;
    for(var i=start;i<=end;i++){
        clearTimeout(i);
    }
}
console.log('scipts load');
yhplFunClearTimeout();
setTimeout(yhplFunTurn,1000);

