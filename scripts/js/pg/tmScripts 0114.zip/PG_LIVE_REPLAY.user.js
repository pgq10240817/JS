// ==UserScript==
// @name         PG_LIVE_REPLAY
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/forum.php?mod=post&action=reply&fid=145&tid=1075758
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';
function yhplReply(){

    // Pre. 1. CODE ID
    var yhplIDInputcodeRaw = document.getElementsByName("secanswer")[0].id;
    var yhplIDInputcodeRawReg = new RegExp("(_)([^_]+$)");   
    var yhplIDInputcodeAfterFix = yhplIDInputcodeRaw.match(yhplIDInputcodeRawReg)[2];
    var yhplIDInputCode = "secqaaverify_"+yhplIDInputcodeAfterFix;
    var yhplIDSpanCode = "secqaa_"+yhplIDInputcodeAfterFix;

    var yhplCodeStr = document.getElementById(yhplIDSpanCode).innerHTML;
    if(yhplCodeStr==null || yhplCodeStr.length==0){
        console.log('user upload erroer code is null');
        return;
    }
    var yhplCodeReg = new RegExp("([^>]+)(<[^<]+$)");   
    var yhplCodeRight = yhplCodeStr.match(yhplCodeReg)[1];
    document.getElementById(yhplIDInputCode).value = yhplCodeRight;
    document.getElementById('e_switchercheck').checked = false;
    document.getElementById('e_switchercheck').click();
    document.getElementById('e_textarea').value = '支持支持。。。。。';
    //document.getElementById('postsubmit').click();
}
 console.log('replay load');
setTimeout(yhplReply,1000);