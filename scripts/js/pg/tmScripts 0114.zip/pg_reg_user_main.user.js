// ==UserScript==
// @name         pg_reg_user_main
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/home.php?mod=spacecp*
// @grant        none
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// ==/UserScript==
/* jshint -W097 */
'use strict';


var yhplPGURLReply = "http://bbs.pinggu.org/thread-1018186-1-1.html";
var yhplPGHOMEURL = "http://bbs.pinggu.org/";
function yhplFunReLoad(){
    var yhplIDUserName = "username";
    var yhplDivUser = document.getElementById(yhplIDUserName);
    var isLogout = yhplDivUser!=null;
    if(isLogout){
        console.log('reply');
        window.location.href = yhplPGURLReply;
    }else{
        console.log('home');
        window.location.href = yhplPGHOMEURL;
    }
}
function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
}
function yhplFunError(){
    console.log('yhplFunError');
}
function yhplLiveMail(){
    console.log('send mail enter');
    $.ajax({
        type: "get",
        url: 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1',
        success: yhplFunUpILiveMail,
        error:yhplFunError,
        dataType: 'json'
    }); 
}
console.log('reg success page load');
//setTimeout(yhplLiveMail,100);

setTimeout(yhplFunReLoad,1000);