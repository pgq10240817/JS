// ==UserScript==
// @name         PG_SIGN_LOGIN
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/member.php?mod=logging&action=login
// @grant        none
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// ==/UserScript==
/* jshint -W097 */
'use strict';


//Pre

var yhplURLLogin = "http://bbs.pinggu.org/member.php?mod=logging&action=login";

var yhplIDUserName = "username_";
var yhplIDUserPwd = "password3_";
var yhplIDUserLogin = "loginsubmit";




function yhplFunLogin(user){
    console.log('login');
    console.log('name,pwd'+user.name+","+user.pwd);
    var yhplIDInputNameRaw = document.getElementsByName("username")[0].id;
    var yhplIDInputNameRawReg = new RegExp("(_)([^_]+$)");   
    var yhplIDInputNameAfterFix = yhplIDInputNameRaw.match(yhplIDInputNameRawReg)[2];
    yhplIDUserName = yhplIDUserName+yhplIDInputNameAfterFix;
    yhplIDUserPwd = yhplIDUserPwd+yhplIDInputNameAfterFix;
    document.getElementById(yhplIDUserName).value = user.name;
    document.getElementById(yhplIDUserPwd).value = user.pwd;
    document.getElementsByName('loginsubmit')[0].click();
}

function yhplFunUserLoad(){
    console.log('req user');
    var yhplGETURL = 'http://182.254.233.156:9000/userpg.avauser';
    $.ajax({
        type: "GET",
        url: yhplGETURL,
        dataType: 'jsonp',
        jsonp:"callback",
        jsonpCallback:"success_jsonpCallback",
        success:yhplFunOnUserLoaded,
        error :yhplFunError
    }); 
}

function yhplFunOnUserLoaded(data){
    if(data == null){
        console.log('get user is null  -->'+data);
    }else{
      yhplFunLogin(data);
    }
   
}
function yhplFunError(){
    console.log('req user error');
}
console.log('scipts load');
setTimeout(yhplFunUserLoad,1000);

