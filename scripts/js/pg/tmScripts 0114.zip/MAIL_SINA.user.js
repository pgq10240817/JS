// ==UserScript==
// @name       MAIL_SINA
// @namespace   test
// @version     1
//@match    https://mail.sina.com.cn/register/regmail.php
//@include https://mail.sina.com.cn/register/regmail.php
// @grant       none
// ==/UserScript==

function yhpllogin(name){
   var pwd = 'pg'+name.substring(8);
	document.getElementsByClassName('inputStyle')[0].value = name;
	document.getElementsByClassName('inputNormal')[0].value = pwd;
    
}
function getUrlPar(name){
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}
function main(){
  var url = window.location.href;
  var name = getUrlPar("name");
  if(name!=null && name.length >0){
    yhpllogin(name);
  }
  
}
console.log('load');
setTimeout(main,1000);
