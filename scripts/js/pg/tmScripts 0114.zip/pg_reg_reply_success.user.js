// ==UserScript==
// @name        pg_reg_reply_success
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/forum.php?mod=viewthread&tid=1018186*
// @require      http://libs.baidu.com/jquery/1.9.0/jquery.js
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';
var yhplPGURL = "http://bbs.pinggu.org/member.php?mod=logging&action=logout";
var yhplPGHOMEURL = "http://bbs.pinggu.org/";
var yhplFlagLiveEmailCount = 0;

function yhplFunReLoad(){
    var yhplIDUserName = "username";
    var yhplDivUser = document.getElementById(yhplIDUserName);
    var isLogout = yhplDivUser!=null;
    if(isLogout){
        console.log('logout');
        window.location.href = yhplPGURL;
    }else{
        console.log('home');
        window.location.href = yhplPGHOMEURL;
    }
}
function yhplFunUpILiveMail(data){
    console.log('yhplFunUpILiveMail:'+data);
    yhplFunReLoad();
}
function yhplFunError(){
    yhplFlagLiveEmailCount = yhplFlagLiveEmailCount + 1;
    console.log('yhplFunError:');
    yhplFunReLoad();

}
function yhplLiveMail(){
    console.log('send mail enter');
    $.ajax({
        type: "get",
        url: 'http://bbs.pinggu.org/home.php?mod=spacecp&ac=profile&op=password&resend=1',
        success: yhplFunUpILiveMail,
        error:yhplFunError,
        dataType: 'json'
    }); 
}

console.log('reg success page load');
setTimeout(yhplLiveMail,1000);
//setTimeout(yhplFunReLoad,3000);