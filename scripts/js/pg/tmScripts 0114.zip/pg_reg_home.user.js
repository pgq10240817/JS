// ==UserScript==
// @name         pg_reg_home
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://bbs.pinggu.org/
// @grant        none
// ==/UserScript==
/* jshint -W097 */
'use strict';

//var yhplPGURLBase = "http://bbs.pinggu.org/member.php?mod=regpinggu&fromuid=";
//var yhplPGURLUID = "7854821";
var yhplPGURLBase = "http://bbs.pinggu.org/member.php?mod=regpinggu";
var yhplPGURLUID = "";
var yhplPGURL = yhplPGURLBase+yhplPGURLUID;
function yhplFunReLoad(){
    console.log('redirect to reg page');
    window.location.href = yhplPGURL;
}
console.log("home page load");
setTimeout(yhplFunReLoad,1000);